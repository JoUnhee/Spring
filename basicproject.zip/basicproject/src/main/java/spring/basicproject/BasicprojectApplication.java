package spring.basicproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BasicprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(BasicprojectApplication.class, args);
	}

}
