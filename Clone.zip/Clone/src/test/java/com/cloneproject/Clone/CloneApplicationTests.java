package com.cloneproject.Clone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloneApplicationTests {

	@Test
	void contextLoads() {
	}

}
